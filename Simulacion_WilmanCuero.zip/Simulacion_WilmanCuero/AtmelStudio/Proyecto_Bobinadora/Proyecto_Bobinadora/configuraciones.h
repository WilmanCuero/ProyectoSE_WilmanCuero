#include <avr/io.h>

void configura();