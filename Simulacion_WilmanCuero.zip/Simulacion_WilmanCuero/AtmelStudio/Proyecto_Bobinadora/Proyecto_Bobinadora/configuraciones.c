#include "configuraciones.h"

void configura(){
}