/*
 * Proyecto_Bobinadora.c
 *
 * Created: 26/07/2021 15:43:55
 * Author : user
 */ 

#include <avr/io.h>
#include "i2c.h"
#include "lcd_i2c.h"
#include "configuraciones.h"
#include <util/delay.h>
#include <avr/interrupt.h>
#include <stdio.h>

char lectura = 0x00;

//Contar las vueltas dadas.
int conteo = 0;
char cont[20];

//Contar la configuraci�n de vueltas.
int digitos;
int *digitosDina;
char dig[20];

//Control de velocidad
int velocidadMotorGiro = 1;
char veloc[20];

//Funciones
ISR (INT0_vect)
{
	conteo = conteo + 1;
	sprintf(cont, "%d" ,conteo );
	//lcd_msg(cont);
	
	/*
	//Encendido de motores
	DDRC |= (1 << DDC0);
	DDRC |= (1 << DDC1);
	DDRC |= (1 << DDC2);
	DDRC |= (1 << DDC3);
	
	PORTC &= ~(1 << PORTC0);
	PORTC &= ~(1 << PORTC1);
	PORTC &= ~(1 << PORTC2);
	PORTC &= ~(1 << PORTC3);
	
	PORTC |= (1 << PORTC0);
	
	_delay_ms(2000);
	
	PORTC &= ~(1<<PORTC0);
	
	PORTC |= (1 << PORTC1);
	
	_delay_ms(2000);
	
	PORTC &= ~(1 << PORTC1);
	*/

}


/*ISR (INT1_vect)
{
	conteo = conteo + 1;
	sprintf(cont, "%d" ,conteo );
	//lcd_msg(cont);
	
}*/




void conf_timer0(){
	DDRD |= (1<<DDD5);
	TCCR0A = (0<<COM0A1)|(0<<COM0A0)|(1<<COM0B1)|(0<<COM0B0)|(1<<WGM01)|(1<<WGM00);
	TCCR0B = (0<<FOC0A)|(0<<FOC0B)|(0<<WGM02)|(0<<CS02)|(1<<CS01)|(0<<CS00);
	 TCNT0 = 0x00;
	 OCR0A = 0x00;
	 OCR0B = 0x00;
	 TIMSK0 = 0x00;
	 
}

void start_timer0(){
	TCCR0B = (0<<FOC0A)|(0<<FOC0B)|(0<<WGM02)|(0<<CS02)|(0<<CS01)|(1<<CS00);
}


/*
//Valores ultra sonico
int pulso = 0;
int i = 0;
int almacena = 0;
char muestra[5];*/

int main(void)
{
    configura();
	i2c_init();
	//i2c_start();
	//i2c_write(0x70);
	lcd_init();
	//lcd_msg("    BIENVENIDO");
	//_delay_ms(2000);
	//lcd_init();
	
	//lcd_msg("N vueltas ?");
	//Interrupcion de conteo
	DDRD &= ~(1 << DDD2);     // PD2 como entrada
	PORTD |= (1 << PORTD2);    // habilita la resistencia pull-up del pin PD2
	//DDRD &= ~(1 << DDD3);     // PD2 como entrada
	//PORTD |= (1 << PORTD3);    // habilita la resistencia pull-up del pin PD2
	EICRA = 0b11;    //  se disparar� la interrupci�n por cualquier subida flanco
	EIMSK |= (1 << INT0);     // enciende INT0
	//EIMSK |= (1 << INT1);     // enciende INT0
    sei(); 	// enciendo las interrupciones
	

    //Interruppciones de ultrosonico
	
	
	//Escritura en el teclado
	DDRB = 0xF0;
	PORTB = 0xFF;
	
	
	/*//Encendido de motores
	DDRC |= (1 << DDC0);
	DDRC |= (1 << DDC1);
	DDRC |= (1 << DDC2);
	DDRC |= (1 << DDC3);
	
	PORTC &= ~(1 << PORTC0);
    PORTC &= ~(1 << PORTC1);
	PORTC &= ~(1 << PORTC2);
	PORTC &= ~(1 << PORTC3);
	
	PORTC |= (1 << PORTC0);
	
	//_delay_ms(2000);
	*/
	
	
	//PWM
	conf_timer0();
	start_timer0();
	//OCR0B = 255;
	
	int a=0;
	int banderaError=0;
	int contadorDigitos=0;
	
    while (1) 
    {
		/*_delay_ms(2000);
		//Sensor Ultrasonico
		PORTD |= (1<<PIND4);
		_delay_ms(2000);
		PORTD &= ~(1<<PIND4);
		//PORTD |= (1<<PIND3);
		almacena = pulso/58;*/
		
		switch(a){
			
			case 0:
			lcd_msg("  BIENVENIDOS");
			_delay_ms(1000);
			lcd_init();
			a=1;
			break;
			
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

			case 1:
			
			contadorDigitos=0;
			digitos=0;
			
			digitosDina = (int*)malloc(3*sizeof(int));
			
			lcd_msg("Numero de                                                       Vueltas?");
			//lcd_cursor(1,0);
			_delay_ms(2000);
			lcd_init();
			lcd_msg("A:Confirmar                                                     B:Error");
			_delay_ms(1000);
			while(1){
				
				if(contadorDigitos<3){
				PORTB = 0xEF;
				lectura = PINB;
				if(lectura == 0xEE){
					if(contadorDigitos==0){
					lcd_init();
					}
					lcd_msg("1");
					_delay_ms(1000);
					contadorDigitos = contadorDigitos + 1;
					digitosDina[contadorDigitos-1]=1;
				}
				if(lectura == 0xED){
					if(contadorDigitos==0){
						lcd_init();
					}
					lcd_msg("4");
					_delay_ms(1000);
					contadorDigitos = contadorDigitos + 1;
					digitosDina[contadorDigitos-1]=4;
				}
				if(lectura == 0xEB){
					if(contadorDigitos==0){
						lcd_init();
					}
					lcd_msg("7");
					_delay_ms(1000);
					contadorDigitos = contadorDigitos + 1;
					digitosDina[contadorDigitos-1]=7;
				}
				
				PORTB = 0xDF;
				lectura = PINB;
				if(lectura == 0xDE){
					if(contadorDigitos==0){
						lcd_init();
					}
					lcd_msg("2");
					_delay_ms(1000);
					contadorDigitos = contadorDigitos + 1;
					digitosDina[contadorDigitos-1]=2;
				}
				if(lectura == 0xDD){
					if(contadorDigitos==0){
						lcd_init();
					}
					lcd_msg("5");
					_delay_ms(1000);
					contadorDigitos = contadorDigitos + 1;
					digitosDina[contadorDigitos-1]=5;
				}
				if(lectura == 0xDB){
					if(contadorDigitos==0){
						lcd_init();
					}
					lcd_msg("8");
					_delay_ms(1000);
					contadorDigitos = contadorDigitos + 1;
					digitosDina[contadorDigitos-1]=8;
				}
				if(lectura == 0xD7){
					if(contadorDigitos==0){
						lcd_init();
					}
					lcd_msg("0");
					_delay_ms(1000);
					contadorDigitos = contadorDigitos + 1;
					digitosDina[contadorDigitos-1]=0;
				}
				
				PORTB = 0xBF;
				lectura = PINB;
				if(lectura == 0xBE){
					if(contadorDigitos==0){
						lcd_init();
					}
					lcd_msg("3");
					_delay_ms(1000);
					contadorDigitos = contadorDigitos + 1;
					digitosDina[contadorDigitos-1]=3;
				}
				if(lectura == 0xBD){
					if(contadorDigitos==0){
						lcd_init();
					}
					lcd_msg("6");
					_delay_ms(1000);
					contadorDigitos = contadorDigitos + 1;
					digitosDina[contadorDigitos-1]=6;
				}
				if(lectura == 0xBB){
					if(contadorDigitos==0){
						lcd_init();
					}
					lcd_msg("9");
					_delay_ms(1000);
					contadorDigitos = contadorDigitos + 1;
					digitosDina[contadorDigitos-1]=9;
				}
			}
				
				
				
				PORTB = 0x7F;
				lectura = PINB;
				if(lectura == 0x7E){
					lcd_msg("A");
					_delay_ms(1000);
					if(contadorDigitos==3){
					digitos = *(digitosDina+0)*100 + *(digitosDina+1)*10 + *(digitosDina+2);
					}
					
					if(contadorDigitos==2){
					digitos = *(digitosDina+0)*10 + *(digitosDina+1);
					}
					
					if(contadorDigitos==1){
					digitos = *(digitosDina+0);
					}
					
					sprintf(dig,"%d",digitos);
					
					a=2;
					banderaError=0;
					free(digitosDina);
					break;
				}
				if(lectura == 0x7D){
					lcd_msg("B");
					_delay_ms(1000);
					banderaError=1;
					a=1;
					free(digitosDina);
					break;
				}
			}
			
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////			
			case 2:
			if(banderaError==1){
				a=0;
			}
			if(banderaError==0){
			lcd_init();
			lcd_msg("VUELTAS   ");
			lcd_msg(dig);
			_delay_ms(1000);
			a=3;
			}
			break;

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			
			case 3:
			lcd_init();
			lcd_msg("   ELIGE LA                                                        VELOCIDAD");
			_delay_ms(1000);
			lcd_init();
			lcd_msg("ESCALA  1: BAJO                                                        10: ALTO");
			_delay_ms(2000);
			lcd_init();
			lcd_msg(" C: SUBE                                                         D: BAJA");
			//_delay_ms(4000);
			
			
			
			while(a=3){
			
			//sprintf(veloc, "%d ", velocidadMotorGiro);
			PORTB = 0x7F;
			lectura = PINB;
			//lcd_init();
			//lcd_msg(" VELOCIDAD  ");
			//lcd_msg(veloc);
			//lcd_cursor(1,1);
			//lcd_msg("A: ���EMBOBINAR!!!");
			//_delay_ms(4000);
			
			if((velocidadMotorGiro>=1)&&(velocidadMotorGiro<=10)){
				
				if(lectura == 0x7B){	
					//lcd_msg("C");
					lcd_init();
					lcd_msg(" VELOCIDAD  ");
					lcd_msg(veloc);
					lcd_cursor(1,1);
					lcd_msg("A: �EMBOBINAR!");
					velocidadMotorGiro = velocidadMotorGiro + 1;
					
					//_delay_ms(1000);
				}
				
				if(lectura == 0x77){
					//lcd_msg("D");
					lcd_init();
					lcd_msg(" VELOCIDAD  ");
					lcd_msg(veloc);
					lcd_cursor(1,1);
					lcd_msg("A: ���EMBOBINAR!!!");
					velocidadMotorGiro = velocidadMotorGiro - 1;
					//_delay_ms(1000);
				}
				
			}
			
			if(velocidadMotorGiro>10){
				velocidadMotorGiro = 10;
			}
			
			if(velocidadMotorGiro<=0){
				velocidadMotorGiro = 1;
			}
			
			sprintf(veloc, "%d ", velocidadMotorGiro);
			
			if(lectura == 0x7E){
				lcd_init();
				//lcd_msg("Velocidad  ");
				//lcd_msg(veloc);
				_delay_ms(2000);
				a = 4;
				break;
			}
			
			}
			
			
			//break;
			
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			
			case 4:
			lcd_init();
			lcd_msg("Bobinando!!  ");
			
			while(a=4){
			OCR0B = 25*velocidadMotorGiro;
			lcd_cursor(1,1);
			lcd_msg(cont);
			lcd_msg("     ");
			lcd_msg(dig);
			//_delay_ms(2000);
			
			//Encendido de motores
			DDRC |= (1 << DDC0);
			DDRC |= (1 << DDC1);
			DDRC |= (1 << DDC2);
			DDRC |= (1 << DDC3);
			
			PORTC &= ~(1 << PORTC0);
			PORTC &= ~(1 << PORTC1);
			PORTC &= ~(1 << PORTC2);
			PORTC &= ~(1 << PORTC3);
			
			PORTC |= (1 << PORTC0);
			
			//_delay_ms(2000);
			
			if(conteo == digitos){
				PORTC &= ~(1<<PORTC0);
				a = 5;
				break;
			}
			//PORTC &= ~(1<<PORTC0);
			
			//PORTC |= (1 << PORTC1);
			
			//_delay_ms(2000);
			
			//PORTC &= ~(1 << PORTC1);

			}
			//break;
			
			case 5:
			lcd_init();
			lcd_msg("gracias");
			
			break;
		}
		
		
		
		//lcd_cursor(1,1);
		lcd_msg(cont);
		//_delay_ms(1000);
		
		/////////////////////////////////////////////////////////////////Teclado
		
		PORTB = 0xEF;
		lectura = PINB;
		if(lectura == 0xEE){
			lcd_msg("1");
			_delay_ms(1000);
		}
		if(lectura == 0xED){
			lcd_msg("4");
			_delay_ms(1000);
		}
		if(lectura == 0xEB){
			lcd_msg("7");
			_delay_ms(1000);
		}
		if(lectura == 0xE7){
			lcd_msg("F");
			_delay_ms(1000);
		}
		
		PORTB = 0xDF;
		lectura = PINB;
		if(lectura == 0xDE){
			lcd_msg("2");
			_delay_ms(1000);
		}
		if(lectura == 0xDD){
			lcd_msg("5");
			_delay_ms(1000);
		}
		if(lectura == 0xDB){
			lcd_msg("8");
			_delay_ms(1000);
		}
		if(lectura == 0xD7){
			lcd_msg("0");
			_delay_ms(1000);
		}
		
		PORTB = 0xBF;
		lectura = PINB;
		if(lectura == 0xBE){
			lcd_msg("3");
			_delay_ms(1000);
		}
		if(lectura == 0xBD){
			lcd_msg("6");
			_delay_ms(1000);
		}
		if(lectura == 0xBB){
			lcd_msg("9");
			_delay_ms(1000);
		}
		if(lectura == 0xB7){
			lcd_msg("G");
			_delay_ms(1000);
		}
		
		PORTB = 0x7F;
		lectura = PINB;
		if(lectura == 0x7E){
			lcd_msg("A");
			_delay_ms(1000);
		}
		if(lectura == 0x7D){
			lcd_msg("B");
			_delay_ms(1000);
		}
		if(lectura == 0x7B){
			lcd_msg("C");
			_delay_ms(1000);
		}
		if(lectura == 0x77){
			lcd_msg("D");
			_delay_ms(1000);
		}
		
		
    }
}

